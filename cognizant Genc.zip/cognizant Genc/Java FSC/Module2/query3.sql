/*3. Inactive Users
Users who haven’t registered for any events in the last 90 days.*/
SELECT 
    u.user_id, u.full_name
FROM 
    Users u
LEFT JOIN 
    Registrations r ON u.user_id = r.user_id
GROUP BY 
    u.user_id
HAVING 
    MAX(IFNULL(r.registration_date, '1900-01-01')) < CURDATE() - INTERVAL 90 DAY;
