import java.util.concurrent.*;
import java.util.*;

public class CallableExample {
    public static void main(String[] args) throws Exception {
        ExecutorService executor = Executors.newFixedThreadPool(3);

        // Define Callable tasks
        Callable<String> task1 = () -> {
            Thread.sleep(1000);
            return "Task 1 complete";
        };

        Callable<String> task2 = () -> {
            Thread.sleep(500);
            return "Task 2 complete";
        };

        Callable<String> task3 = () -> {
            return "Task 3 complete";
        };

        // Submit tasks
        List<Future<String>> futures = executor.invokeAll(List.of(task1, task2, task3));

        // Get results
        for (Future<String> future : futures) {
            System.out.println(future.get());
        }

        executor.shutdown();
    }
}
