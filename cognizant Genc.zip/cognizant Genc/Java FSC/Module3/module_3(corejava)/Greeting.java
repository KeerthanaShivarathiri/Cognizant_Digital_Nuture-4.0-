//34. Create and Use Java Modules 
public class Greeting {
    public String sayHello(String name) {
        return "Hello, " + name + "!";
    }

    public static void main(String[] args) {
        Greeting g = new Greeting();
        System.out.println(g.sayHello("World"));
    }
}
