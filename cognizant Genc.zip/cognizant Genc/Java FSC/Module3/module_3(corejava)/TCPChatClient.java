//35. TCP Client-Server Chat

import java.io.*;
import java.net.*;

public class TCPChatClient {
    public static void main(String[] args) throws IOException {
        Socket socket = new Socket("localhost", 5000);
        System.out.println("Connected to server.");

        BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
        BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));

        String messageFromServer, messageToServer;
        while (true) {
            System.out.print("Client: ");
            messageToServer = userInput.readLine();
            output.println(messageToServer);
            if (messageToServer.equalsIgnoreCase("bye")) {
                break;
            }
            messageFromServer = input.readLine();
            System.out.println("Server: " + messageFromServer);
        }

        socket.close();
    }
}
