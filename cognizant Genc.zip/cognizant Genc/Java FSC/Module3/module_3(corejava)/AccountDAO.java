//33. Transaction Handling in JDBC 
import java.sql.*;

public class AccountDAO {
    private final String url = "jdbc:mysql://localhost:3306/college_db";
    private final String user = "root";
    private final String password = "password";

    // Transfer amount from one account to another with transaction
    public boolean transferMoney(int fromAccountId, int toAccountId, double amount) {
        String debitSQL = "UPDATE accounts SET balance = balance - ? WHERE account_id = ? AND balance >= ?";
        String creditSQL = "UPDATE accounts SET balance = balance + ? WHERE account_id = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            // Start transaction
            conn.setAutoCommit(false);

            try (PreparedStatement debitStmt = conn.prepareStatement(debitSQL);
                 PreparedStatement creditStmt = conn.prepareStatement(creditSQL)) {

                // Debit from source account
                debitStmt.setDouble(1, amount);
                debitStmt.setInt(2, fromAccountId);
                debitStmt.setDouble(3, amount);
                int debitRows = debitStmt.executeUpdate();

                if (debitRows == 0) {
                    // Not enough balance or account doesn't exist
                    conn.rollback();
                    System.out.println("Debit failed: insufficient balance or account not found.");
                    return false;
                }

                // Credit to target account
                creditStmt.setDouble(1, amount);
                creditStmt.setInt(2, toAccountId);
                int creditRows = creditStmt.executeUpdate();

                if (creditRows == 0) {
                    // Target account doesn't exist
                    conn.rollback();
                    System.out.println("Credit failed: target account not found.");
                    return false;
                }

                // If both succeed, commit
                conn.commit();
                System.out.println("Transfer successful!");
                return true;

            } catch (SQLException e) {
                conn.rollback();
                e.printStackTrace();
                return false;
            } finally {
                conn.setAutoCommit(true);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
public class Main {
    public static void main(String[] args) {
        AccountDAO accountDAO = new AccountDAO();

        boolean success = accountDAO.transferMoney(1, 2, 1500.00);
        System.out.println("Transfer success? " + success);
    }
}
