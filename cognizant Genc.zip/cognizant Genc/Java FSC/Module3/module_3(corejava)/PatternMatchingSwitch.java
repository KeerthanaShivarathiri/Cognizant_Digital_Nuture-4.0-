//30.PatternMatchingSwitch

public class PatternMatchingSwitch {

    public static void main(String[] args) {
        testObject(42);
        testObject("Hello");
        testObject(3.14);
        testObject(true);
        testObject(null);
    }

    public static void testObject(Object obj) {
        String result = switch (obj) {
            case Integer i -> "It is an Integer: " + i;
            case String s -> "It is a String: " + s;
            case Double d -> "It is a Double: " + d;
            case Boolean b -> "It is a Boolean: " + b;
            case null -> "It is null";
            default -> "Unknown type: " + obj.getClass().getName();
        };

        System.out.println(result);
    }
}
