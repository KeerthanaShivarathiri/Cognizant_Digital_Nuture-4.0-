//21.Try-Catch example
import java.util.Scanner;
public class TryCatch{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a num1 : ");
        int num1=sc.nextInt();
        System.out.println("Enter a num1 : ");
        int num2=sc.nextInt();
        try{
            int divi=num1/num2;
            System.out.println("Result : "+divi);
        }catch(ArithmeticException e){
            System.out.println("Error: num2 should not be zero");
        }
        catch(Exception e){
            System.out.println("Error : "+e.getMessage());
        }
        finally{
            System.out.println("PROGRAM ENDS");
        }
    }
}
