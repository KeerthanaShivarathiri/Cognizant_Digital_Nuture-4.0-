//6.DataTypeDemonstration

import java.util.Scanner;
public class  DataTypeDemonstration{
    public static void main(String[] args){
        int num = 80;
        char ch = 'A' ;
        double dou=90.4;
        boolean bool=true;

        Object obj1 = num;
        Object obj2 = ch;
        Object obj3 = dou;
        Object obj4 = bool;
        System.out.println("datatype of the variable "+num+" is "+obj1.getClass().getSimpleName());
        System.out.println("datatype of the variable "+ch+" is "+obj2.getClass().getSimpleName());
        System.out.println("datatype of the variable "+dou+" is "+obj3.getClass().getSimpleName());
        System.out.println("datatype of the variable "+bool+" is "+obj4.getClass().getSimpleName());
    }
}
