//25.hashmap example

import java.util.Scanner;
import java.util.HashMap;
public class HashMapExample{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        HashMap<Integer,String> studentnames=new HashMap<>();
        System.out.println("enter student names : ");
        while(true){
            System.out.println("enter id : ");
            int id=sc.nextInt();
            sc.nextLine();
            if(id==-1){
                break;
            }
            System.out.println("enter names : ");
            String name=sc.nextLine();
            studentnames.put(id,name);
        }
        System.out.print("\nEnter a Student ID to search: ");
        int searchId = sc.nextInt();

        if (studentnames.containsKey(searchId)) {
            System.out.println("Student Name: " + studentnames.get(searchId));
        } else {
            System.out.println("Student ID not found.");
        }



    }
}