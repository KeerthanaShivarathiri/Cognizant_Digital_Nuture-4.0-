//8.Operator Precedence

import java.util.Scanner;
public class OperatorPrecedence{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int result1=10+5*3+1;
        int result2=(10+5)*3+1;
        int result3=20-4/2*6;
        int result4=100/4+35*4;
        int result5=(100%4)*2+5;
        System.out.println("Result of the expression : "+result1);
        System.out.println("Result of the expression : "+result2);
        System.out.println("Result of the expression : "+result3);
        System.out.println("Result of the expression : "+result4);
        System.out.println("Result of the expression : "+result5);
       
    }
}
