// 22.Custom Exception Class
import java.util.Scanner;
class InvalidAgeValidatorException extends Exception{
    public InvalidAgeValidatorException(String message){
        super(message);
    }
}
public class AgeValidator{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("ENTER AGE : ");
        int age=sc.nextInt();
        try{
            if(age<18){
                throw new InvalidAgeValidatorException("Age must be above 18");
            }
            System.out.println("Age is validated ur eligible.");
        }
        catch(InvalidAgeValidatorException e){
            System.out.println("InvalidAgeValidatorException : "+e.getMessage());
        }
        catch(Exception e){
            System.out.println("Exception : "+e.getMessage());
        }
        finally{
            System.out.println("PROGRAM ENDED");
        }

    }
}