//24. ArrayList Example 

import java.util.Scanner;
import java.util.ArrayList;
public class ArrayListExample{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        ArrayList<String> studentnames=new ArrayList<>();
        System.out.println("enter student names : ");
        while(true){
            System.out.println("enter names : ");
            String name=sc.nextLine();
            if(name.equalsIgnoreCase("done")){
                break;
            }
            studentnames.add(name);
        }
        System.out.println("List of students : ");
        for(String student : studentnames){
            System.out.println(student);
        }


    }
}