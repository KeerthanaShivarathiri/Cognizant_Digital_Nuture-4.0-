CREATE TABLE accounts (
    account_id INT PRIMARY KEY,
    account_holder VARCHAR(50),
    balance DECIMAL(15, 2)
);
INSERT INTO accounts VALUES (1, 'Alice', 5000.00);
INSERT INTO accounts VALUES (2, 'Bob', 3000.00);
