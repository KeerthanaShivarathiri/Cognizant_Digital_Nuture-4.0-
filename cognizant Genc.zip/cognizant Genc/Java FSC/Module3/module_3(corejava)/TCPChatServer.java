//35. TCP Client-Server Chat

import java.io.*;
import java.net.*;

public class TCPChatServer {
    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(5000);
        System.out.println("Server started. Waiting for a client...");

        Socket socket = serverSocket.accept();
        System.out.println("Client connected.");

        BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
        BufferedReader serverInput = new BufferedReader(new InputStreamReader(System.in));

        String messageFromClient, messageToClient;
        while (true) {
            messageFromClient = input.readLine();
            if (messageFromClient.equalsIgnoreCase("bye")) {
                System.out.println("Client ended the chat.");
                break;
            }
            System.out.println("Client: " + messageFromClient);
            System.out.print("Server: ");
            messageToClient = serverInput.readLine();
            output.println(messageToClient);
        }

        socket.close();
        serverSocket.close();
    }
}
