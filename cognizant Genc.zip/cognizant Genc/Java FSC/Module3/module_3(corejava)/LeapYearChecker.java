//4. Leap Year Checker

import java.util.Scanner;
public class LeapYearChecker{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter year to check leap year or not");
        int year=sc.nextInt();
        if(year%4==0 ){
            if(year%100==0){
                if(year%400==0){
                    System.out.println("Leap year");
                }
                else{
                    System.out.println("Not Leap year");
                }
                
            }
            else{
                System.out.println("Leap year");
            }
            
        }
        else{
            System.out.println("Not a Leap year");

        }
    }
}