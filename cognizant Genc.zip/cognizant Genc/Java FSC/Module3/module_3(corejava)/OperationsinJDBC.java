//32. Insert and Update Operations in JDBC


import java.sql.*;

public class OperationsinJDBC{
    private final String url = "jdbc:mysql://localhost:3306/college_db";
    private final String user = "root";           // change to your DB user
    private final String password = "password";   // change to your DB password

    // Insert new student record
    public boolean insertStudent(int id, String name, int age, String grade) {
        String sql = "INSERT INTO students (id, name, age, grade) VALUES (?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            pstmt.setString(2, name);
            pstmt.setInt(3, age);
            pstmt.setString(4, grade);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Update student details by id
    public boolean updateStudent(int id, String name, int age, String grade) {
        String sql = "UPDATE students SET name = ?, age = ?, grade = ? WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, name);
            pstmt.setInt(2, age);
            pstmt.setString(3, grade);
            pstmt.setInt(4, id);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
public class Main {
    public static void main(String[] args) {
        StudentDAO dao = new StudentDAO();

        // Insert a new student
        boolean inserted = dao.insertStudent(4, "David", 23, "B");
        System.out.println("Inserted: " + inserted);

        // Update an existing student
        boolean updated = dao.updateStudent(2, "Bob Marley", 23, "A+");
        System.out.println("Updated: " + updated);
    }
}

