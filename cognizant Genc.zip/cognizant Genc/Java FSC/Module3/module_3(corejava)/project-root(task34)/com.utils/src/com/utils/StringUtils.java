package com.utils;

public class StringUtils {
    public static String toUpperCase(String input) {
        return input == null ? null : input.toUpperCase();
    }
}
