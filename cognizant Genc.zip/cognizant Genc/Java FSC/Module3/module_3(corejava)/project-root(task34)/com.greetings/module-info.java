module com.greetings {
    requires com.utils;
}
