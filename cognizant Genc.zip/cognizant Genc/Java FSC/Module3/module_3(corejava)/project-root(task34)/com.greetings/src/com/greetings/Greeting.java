package com.greetings;

import com.utils.StringUtils;

public class Greeting {
    public static void main(String[] args) {
        String name = "world";
        System.out.println("Hello, " + StringUtils.toUpperCase(name) + "!");
    }
}
