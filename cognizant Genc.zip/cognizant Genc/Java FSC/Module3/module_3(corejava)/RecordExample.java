//29.RecordExample
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

record Person(String name, int age) {}

public class RecordExample {
    public static void main(String[] args) {
        // Create instances of Person
        Person p1 = new Person("Keerthana", 21);
        Person p2 = new Person("Anjali", 17);
        Person p3 = new Person("Bhavana", 23);
        Person p4 = new Person("Chandana", 16);

        // Add them to a list
        List<Person> people = Arrays.asList(p1, p2, p3, p4);

        // Print all persons
        System.out.println("All persons:");
        people.forEach(System.out::println);

        // Filter and display persons aged 18 and above
        List<Person> adults = people.stream().filter(person -> person.age() >= 18).collect(Collectors.toList());

        System.out.println("\nAdults (age >= 18):");
        adults.forEach(System.out::println);
    }
}
