//18.Class and Object Creation


class ClassandObjectCreation{
    String make;
    String model;
    int year;
    ClassandObjectCreation(String make,String model,int year){
        this.make=make;
        this.model=model;
        this.year=year;
    }
    void displayDetails(){
        System.out.println("Car details");
        System.out.println("Make  : "+make);
        System.out.println("Model : "+model);
        System.out.println("Year  : "+year);
    }
    public static void main(String[] args){
        ClassandObjectCreation car1=new ClassandObjectCreation("TATA","BMW",2004);
        ClassandObjectCreation car2=new ClassandObjectCreation("HONDA","CIVIC",2025);
        car1.displayDetails();
        car2.displayDetails();

    }

}