//13.RecursiveFibonacci

import java.util.Scanner;
public class RecursiveFibonacci{
    public static int fibona(int n){
        if(n<=1){
            return n;
        }
        return fibona(n-1)+fibona(n-2);
        
    }
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a positive number : ");
        int n=sc.nextInt();
        if(n<0){
            System.out.println("number is negative");
        }
        else{
            int result=fibona(n);
            System.out.println(result);
        }
    }
  
}