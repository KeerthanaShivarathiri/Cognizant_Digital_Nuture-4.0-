//7. Type Casting Example
import java.util.Scanner;
public class TypeCasting{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter Integer");
        int myint1=sc.nextInt();
        System.out.println("Enter Double : ");
        double mydouble1=sc.nextDouble();
        int myint2=(int) mydouble1;
        double mydouble2= myint1;
        System.out.println("Original Value of Integer : "+myint1);
        System.out.println("Tycasting value of Integer into double : "+mydouble2);
        System.out.println("Original Value of Double : "+mydouble1);
        System.out.println("Tycasting value of  double into Integer : "+myint2);

    }
}