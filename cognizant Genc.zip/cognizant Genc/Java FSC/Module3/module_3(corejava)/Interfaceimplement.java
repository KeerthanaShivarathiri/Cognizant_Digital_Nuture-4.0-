//20.Interface Implementation


interface Playable{
    void play();
}
class Guitar implements Playable{
    @Override
    public void play(){
        System.out.println("plays guitar...........");
    }
}
class Piano implements Playable{
    @Override
    public void play(){
        System.out.println("plays Piano............");
    }
}
public class Interfaceimplement{
    public static void main(String[] args){
        Playable a=new Guitar();
        Playable b=new Piano();
        a.play();
        b.play();
    }
}