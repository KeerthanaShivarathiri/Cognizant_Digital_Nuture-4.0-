//16.PalindromeChecker 

import java.util.Scanner;
public class PalindromeChecker {
    public static boolean palindrome(String input){
        
        String cleaned=input.replaceAll("[^a-zA-Z0-9]","").toLowerCase();
        int left=0;
        int right=cleaned.length()-1;
        while(left<right){
            if(cleaned.charAt(left)!=cleaned.charAt(right)){
                return false;
            }
            left++;
            right--;

        }
        return true;
    }
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        String input=sc.nextLine();
        if(palindrome(input)){
            System.out.println(input+" is a palindrome");
        }
        else{
            System.out.println(" is not a palindrome");
        }
    }
}