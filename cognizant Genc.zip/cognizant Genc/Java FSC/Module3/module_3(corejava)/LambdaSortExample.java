//27.Lambda Expressions 

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class LambdaSortExample {
    public static void main(String[] args) {
        List<String> names = new ArrayList<>();

        // Adding names to the list
        names.add("Keerthana");
        names.add("Anjali");
        names.add("Bhavana");
        names.add("Divya");
        names.add("Chandana");

        // Sorting using lambda expression
        Collections.sort(names, (s1, s2) -> s1.compareTo(s2));

        // Displaying the sorted list
        System.out.println("Sorted list of names:");
        for (String name : names) {
            System.out.println(name);
        }
    }
}
