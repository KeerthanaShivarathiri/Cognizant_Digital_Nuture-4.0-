//39. Reflection in Java 

import java.lang.reflect.*;

public class ReflectionExample {
    public static void main(String[] args) throws Exception {
        // Load class dynamically
        Class<?> clazz = Class.forName("Sample");

        // List methods
        Method[] methods = clazz.getDeclaredMethods();
        System.out.println("Methods:");
        for (Method m : methods) {
            System.out.print("- " + m.getName() + "(");
            for (Parameter p : m.getParameters()) {
                System.out.print(p.getType().getSimpleName() + " ");
            }
            System.out.println(")");
        }

        // Create instance
        Object obj = clazz.getDeclaredConstructor().newInstance();

        // Call method dynamically
        Method greetMethod = clazz.getDeclaredMethod("greet", String.class);
        greetMethod.invoke(obj, "Java");
    }
}

class Sample {
    public void greet(String name) {
        System.out.println("Hello, " + name + "!");
    }

    public int add(int a, int b) {
        return a + b;
    }
}
