//12.Method Overloading 

public class MethodOverloading{
    public static int add(int a,int b){
        return a+b;
    }
    public static double add(double a,double b){
        return a+b;
    }
    public static int add(int a,int b,int c){
        return a+b+c;
    }
    public static void main(String[] args){
        int result1=add(10,20);
        double result2=add(38.67,78.29);
        int result3=add(10,20,70);
        System.out.println("Result of two integers : "+result1);
        System.out.println("Result of two doubles : "+result2);
        System.out.println("Result of three integers : "+result3);
        
    }
} 