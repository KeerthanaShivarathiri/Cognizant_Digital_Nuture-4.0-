//15. String Reversal


import java.util.Scanner;
public class  StringReversal{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        String str1=sc.nextLine();
        String str2=sc.nextLine();
        

        //using stringbuilder
        StringBuilder rev=new StringBuilder(str1).reverse();
        System.out.println("Reversed string : "+rev);

        //using for loop
        String rev1="";
        for(int i=str2.length()-1;i>=0;i--){
            rev1+=str2.charAt(i);
        }
        System.out.println("Reversed string : "+rev1);

    }
}
