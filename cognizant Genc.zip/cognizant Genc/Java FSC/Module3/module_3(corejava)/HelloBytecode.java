//37. Using javap to Inspect Bytecode 
public class HelloBytecode {
    public int add(int a, int b) {
        return a + b;
    }

    public static void main(String[] args) {
        HelloBytecode obj = new HelloBytecode();
        int result = obj.add(5, 3);
        System.out.println("Result: " + result);
    }
}
//OUTPUT
/*javap -c HelloBytecode

Compiled from "HelloBytecode.java"
public class HelloBytecode {
  public HelloBytecode();
    Code:
       0: aload_0
       1: invokespecial #1                  // Method java/lang/Object."<init>":()V
       4: return

  public int add(int, int);
    Code:
       0: iload_1
       1: iload_2
       2: iadd
       3: ireturn

  public static void main(java.lang.String[]);
    Code:
       0: new           #7                  // class HelloBytecode     
       3: dup
       4: invokespecial #9                  // Method "<init>":()V     
       7: astore_1
       8: aload_1
       9: iconst_5
      10: iconst_3
      11: invokevirtual #10                 // Method add:(II)I
      14: istore_2
      15: getstatic     #14                 // Field java/lang/System.out:Ljava/io/PrintStream;
      18: iload_2
      19: invokedynamic #20,  0             // InvokeDynamic #0:makeConcatWithConstants:(I)Ljava/lang/String;
      24: invokevirtual #24                 // Method java/io/PrintStream.println:(Ljava/lang/String;)V
      27: return
}
PS C:\Users\Keerthana Shivaratri\OneDrive\Desktop\MODULE 3 (CORE JAVA)>
 */