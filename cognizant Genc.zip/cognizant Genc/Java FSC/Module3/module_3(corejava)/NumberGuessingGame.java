import java.util.Scanner;
import java.util.Random;
public class NumberGuessingGame{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        Random random=new Random();
        int guessnum=random.nextInt(100)+1;
        int guess1=0;

        System.out.println("Welcome to number guessing game!!!!!");
        System.out.println("we generate a number from 1 to 100 can u generate it????");
        System.out.println("Lets start the game!!!!!!");


        while (guess1 !=guessnum){
            System.out.println("Enter a number ");
            int guess=sc.nextInt();
            if(guess<guessnum){
                System.out.println("too low from the number!!!");
                System.out.println("try again");
            }
            else if(guess>guessnum){
                System.out.println("too high from the number!!!");
                System.out.println("try again");
            }
            else{
                System.out.println("congrats!!!!!! you guessed the number "+guess);
            }
        }
    } 

}