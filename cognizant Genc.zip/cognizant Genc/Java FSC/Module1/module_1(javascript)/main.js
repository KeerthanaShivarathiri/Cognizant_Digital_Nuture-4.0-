console.log("Welcome to the Community Portal");

window.onload = function() {
  alert("Page is fully loaded");
  loadInitialEvents();
};

// Event Constructor and prototype
function Event(name, date, seats, category = "General") {
  this.name = name;
  this.date = new Date(date);
  this.seats = seats;
  this.category = category;
}
Event.prototype.checkAvailability = function() {
  const today = new Date();
  return this.seats > 0 && this.date >= today;
};

// Initial event list
let allEvents = [
  new Event("Local Music Festival", "2025-06-30", 50, "Music"),
  new Event("Cooking Workshop", "2025-08-10", 30, "Workshop"),
  new Event("Jazz Night", "2025-06-15", 20, "Music"),
  new Event("Art Workshop", "2025-07-10", 10, "Workshop"),
  new Event("Community Meetup", "2024-12-01", 0, "General"), // past event
  new Event("Rock Concert", "2025-06-22", 0, "Music") // full event
];

const eventsContainer = document.querySelector("#eventsContainer");
const categoryFilter = document.querySelector("#categoryFilter");
const searchInput = document.querySelector("#searchInput");
const registerForm = document.querySelector("#registerForm");
const formError = document.querySelector("#formError");
const spinner = document.querySelector("#spinner");
const eventSelect = registerForm.eventSelect;

// Function to render event cards in DOM
function renderEvents(events) {
  eventsContainer.innerHTML = "";
  eventSelect.innerHTML = '<option value="">Select Event</option>'; // reset select options

  events.forEach(event => {
    if (!event.checkAvailability()) return;

    // Add options for registration select
    const option = document.createElement("option");
    option.value = event.name;
    option.textContent = `${event.name} (${event.date.toDateString()})`;
    eventSelect.appendChild(option);

    // Create event card
    const card = document.createElement("div");
    card.className = "event-card";
    card.innerHTML = `
      <h3>${event.name}</h3>
      <p>Date: ${event.date.toDateString()}</p>
      <p>Seats available: ${event.seats}</p>
      <button class="register-btn" data-event="${event.name}">Register</button>
    `;
    eventsContainer.appendChild(card);
  });
}

// Function to register user for event
function registerUser(eventName) {
  try {
    const event = allEvents.find(e => e.name === eventName);
    if (!event) throw new Error("Event not found");
    if (event.seats <= 0) throw new Error("No seats available");
    event.seats--;
    console.log(`User registered for ${eventName}. Seats left: ${event.seats}`);
    alert(`Successfully registered for ${eventName}!`);
    renderEventsFiltered();
  } catch (error) {
    alert(error.message);
  }
}

// Filter events by category and search term
function renderEventsFiltered() {
  let filtered = [...allEvents]; // clone array
  const selectedCategory = categoryFilter.value;
  const searchTerm = searchInput.value.toLowerCase();

  if (selectedCategory) {
    filtered = filtered.filter(e => e.category === selectedCategory);
  }
  if (searchTerm) {
    filtered = filtered.filter(e => e.name.toLowerCase().includes(searchTerm));
  }
  renderEvents(filtered);
}

// Event listeners
categoryFilter.onchange = renderEventsFiltered;
searchInput.onkeydown = renderEventsFiltered;

// Delegate click for register buttons
eventsContainer.onclick = function(e) {
  if (e.target.classList.contains("register-btn")) {
    const eventName = e.target.dataset.event;
    registerUser(eventName);
  }
};

// Handle form submission
registerForm.addEventListener("submit", async function(e) {
  e.preventDefault();
  formError.textContent = "";

  const { userName, email, eventSelect: eventSel } = registerForm.elements;
  if (!userName.value || !email.value || !eventSel.value) {
    formError.textContent = "Please fill all fields.";
    return;
  }

  // Simulate POST request with timeout
  spinner.style.display = "block";
  try {
    await new Promise(resolve => setTimeout(resolve, 1500)); // simulate delay
    registerUser(eventSel.value);
    registerForm.reset();
  } catch {
    alert("Registration failed. Please try again.");
  } finally {
    spinner.style.display = "none";
  }
});

// Initial load
function loadInitialEvents() {
  // In a real app, this would fetch from API, here we just render
  spinner.style.display = "block";
  setTimeout(() => {
    spinner.style.display = "none";
    renderEventsFiltered();
  }, 1000);
}
